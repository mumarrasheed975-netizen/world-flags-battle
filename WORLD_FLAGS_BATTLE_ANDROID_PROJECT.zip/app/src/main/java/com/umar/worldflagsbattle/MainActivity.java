package com.umar.worldflagsbattle;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.speech.tts.TextToSpeech;
import android.view.View;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        tts = new TextToSpeech(this, status -> { if(status == TextToSpeech.SUCCESS) { tts.setLanguage(Locale.US); tts.setSpeechRate(0.94f); ttsReady = true; } });
        webView = new WebView(this);
        WebSettings settings = webView.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new Object(){ @JavascriptInterface public void speak(String text){ runOnUiThread(() -> { if(ttsReady && text != null) tts.speak(text, TextToSpeech.QUEUE_ADD, null, "battle_"+System.currentTimeMillis()); }); } }, "AndroidTTS");
        setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed(){ if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy(){ if(tts!=null){tts.stop();tts.shutdown();} if(webView!=null)webView.destroy(); super.onDestroy(); }
}
